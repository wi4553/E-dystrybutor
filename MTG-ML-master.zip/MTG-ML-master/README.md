# MTG-ML
Machine Learning Project For Classifying Magic Card Images using a Convolutional Neural Network
